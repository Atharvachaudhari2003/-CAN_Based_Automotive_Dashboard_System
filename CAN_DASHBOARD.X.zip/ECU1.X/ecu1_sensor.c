/*
 * File:   ecu1_sensor.c
 * Author: DELL
 *
 * Created on 20 March, 2026, 3:41 PM
 */


#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include"string.h"
#define _XTAL_FREQ 20000000


void get_speed()
{
    // Implement the speed function
    uint16_t static prev = 0;
    uint16_t adc_value = read_adc(SPEED_ADC_CHANNEL);
    uint8_t speed = adc_value / 10.3;
    
    if(speed != prev)
    {
        prev = speed;
        uint8_t arr[3];
        arr[0] = (speed / 10) + '0';
        arr[1] = (speed % 10) + '0';
        arr[2] = '\0';
        can_transmit(SPEED_MSG_ID, arr, 3); 
    }   
}

void get_gear_pos()
{
    // Implement the gear function
    uint8_t key = 0;
    uint8_t static idx = 0;
    uint8_t static prev_key = 0;
    key = read_digital_keypad(STATE_CHANGE);
    if(key != prev_key)
    {
        if(key == GEAR_UP)
        {
            if(idx < MAX_GEAR)
            {
                idx++;
            }   
        }
        if(key == GEAR_DOWN)
        {
            if(idx > 0)
            {
                idx--;
            }   
        }
        if(key == COLLISION)
        {
            idx = 7;
        }
        if((key == GEAR_UP || key == GEAR_DOWN) && idx == 7)
        {
            idx = MAX_GEAR;
        }
        can_transmit(GEAR_MSG_ID, &gear_arr[idx], 1);
    }
}