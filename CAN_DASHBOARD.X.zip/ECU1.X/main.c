/*
 * File:   main.c
 * Author: DELL
 *
 * Created on 16 March, 2026, 10:52 AM
 */


/*
 * TITLE : CAN BASED AUTOMOTIVE DASHBOARD SYSTEM
 * In ECU1, the vehicle speed is measured using rotating the potentiometer knob through ADC channel. 
 * The gear position and collision detection is controlled using digital keypad switches.
 * In ECU2, the RPM is measured using rotating the potentiometer knob through ADC channel. 
 * The indicator functionality is implemented using digital keypad, pressing a switch activates 
   either left or right indicators, which blink corresponding LED?s. The engine temperature is measured using a LM35 sensor.
 * ECU3 acts as the dashboard unit. It receives data from both ECU1 and ECU2 via CAN communication 
   and displays parameters like speed, gear position, RPM, engine temperature and indicator status on 16x2 LCD. 

 */

#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include"string.h"
#define _XTAL_FREQ  20000000

void init_config(void)
{
    init_digital_keypad();
    init_can();
    init_adc();
}
int main()
{
    //Call the functions
    init_config();
    while(1)
    {
        get_speed();
        __delay_ms(80);
        
        get_gear_pos();
        __delay_ms(50);
        
    }
    
}