/*
 * File:   ecu2_sensor.c
 * Author: DELL
 *
 * Created on 22 March, 2026, 9:51 AM
 */


#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "digital_keypad.h"

void get_rpm()
{
    //Implement the rpm function
    static uint16_t prev = 0;
    uint16_t rpm_value = 0;
    rpm_value = read_adc(RPM_ADC_CHANNEL);
    rpm_value = (rpm_value * 5.866);
    if(rpm_value != prev)
    {
        prev = rpm_value;
        uint8_t a[5];
        a[0] = (rpm_value / 1000) + '0';
        a[1] = ((rpm_value / 100) % 10) + '0';
        a[2] = ((rpm_value / 10) % 10) + '0';
        a[3] = (rpm_value % 10) + '0';
        a[4] = '\0';
        can_transmit(RPM_MSG_ID,a,5);
    }
}

void get_engine_temp()
{
    //Implement the engine temperature function
    uint16_t adc_value = read_adc(CHANNEL6);
    uint8_t temp = ((adc_value * 500) / 1023);
    
    uint8_t a[3];
    a[0] = (temp / 100) + '0';
    a[1] = (temp % 10) + '0';
    a[2] = '\0';
    can_transmit(ENG_TEMP_MSG_ID, a, 3);
}

IndicatorStatus process_indicator()
{
    //Implement the indicator function
    uint8_t key = 0;
    static IndicatorStatus state = e_ind_off;
    static uint8_t prev_key = 0;
    
    key = read_digital_keypad(STATE_CHANGE);
    if(key != prev_key)
    {
        prev_key = key;
        if(key == SWITCH1)
        {
            state =  e_ind_left;
        }
        if(key == SWITCH2)
        {
            state = e_ind_right;
        }
        if(key == SWITCH3)
        {
            state = e_ind_off;
        }
        uint8_t a[2];
        a[0] = state;
        a[1] = '\0';
        
        can_transmit(INDICATOR_MSG_ID,a,2);       
    }
}