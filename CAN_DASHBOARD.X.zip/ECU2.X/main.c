/*
 * File:   main.c
 * Author: DELL
 *
 * Created on 16 March, 2026, 5:52 PM
 */


#include <xc.h>
#include"adc.h"
#include"can.h"
#include"digital_keypad.h"
#include"msg_id.h"
#include"ecu2_sensor.h"
#define _XTAL_FREQ  20000000


void init_config(void)
{
    init_adc();
    init_can();
    init_digital_keypad();    
}
void main(void) 
{
    init_config();

    while(1)
    {
        get_rpm();
        __delay_ms(50);
        
        get_engine_temp();
        __delay_ms(50);
        
        process_indicator();
        __delay_ms(50);
    }
    return;
}
