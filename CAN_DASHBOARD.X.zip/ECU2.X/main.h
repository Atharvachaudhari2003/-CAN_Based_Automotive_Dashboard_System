#ifndef MAIN_H
#define MAIN_H

unsigned char gear_arr[7][10] = {"Neutral","1st Gear","2nd Gear","3rd Gear","4th Gear","5th Gear","Reverse"};

#endif