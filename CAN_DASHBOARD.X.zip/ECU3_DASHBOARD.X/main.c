/*
 * File:   main.c
 * Author: DELL
 *
 * Created on 20 March, 2026, 4:40 PM
 */


#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"
#include "timer0.h"
#include"adc.h"

unsigned int count = 0;
uint8_t flag = 0;

static void init_leds() 
{
    TRISB = 0x08; // Set RB2 as output, RB3 as input, remaining as output
    PORTB = 0x00;
}

static void init_config(void) 
{
    // Initialize CLCD and CANBUS
    init_clcd();
    init_can();
    init_leds();
    
    // Enable Interrupts
    PEIE = 1;
    GIE = 1;
    init_timer0();
}


void main(void) 
{
    // Initialize peripherals
    init_config();
    clcd_print("SPD:", LINE1(0));
    clcd_print("G:" , LINE1(7));
    clcd_print("ID:", LINE1(11));
    clcd_print("RPM:", LINE2(0));
    clcd_print("TMP:", LINE2(9));
    

    while (1) 
    {
        // Read CAN Bus data and handle it
        
        if(flag == 0)
        {
            PORTB = LED_OFF;
            count = 0;
        }
        if(flag == 1)
        {
            if(count < 10000)
            {
                LEFT_IND_OFF();
            }
            else if(count < 20000)
            {
                LEFT_IND_ON();
            }
            else
                count = 0;
        }
        if(flag == 2)
        {
            if(count < 10000)
            {
                RIGHT_IND_OFF();
            }
            else if(count < 20000)
            {
                RIGHT_IND_ON();
            }
            else
                count = 0; 
        }
        
        process_canbus_data();

    }

    return;
}
