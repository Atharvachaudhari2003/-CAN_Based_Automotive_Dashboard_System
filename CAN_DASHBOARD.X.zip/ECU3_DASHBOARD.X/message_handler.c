/*
 * File:   message_handler.c
 * Author: DELL
 *
 * Created on 20 March, 2026, 4:36 PM
 */


#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"


volatile unsigned char led_state = LED_OFF, status = e_ind_off;

//volatile uint8_t blink_flag = 0;
extern unsigned int count;
extern uint8_t flag;

void handle_speed_data(uint8_t *data, uint8_t len)
{
    //Implement the speed function    
    clcd_print(data, LINE1(4));
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    //Implement the gear function
    if(data[0] == 'C')
    {
        CLEAR_DISP_SCREEN;
        clcd_print("Collision" , LINE1(0));
        while(1);
    }
    clcd_putch(data[0] , LINE1(9));
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    //Implement the rpm function
    clcd_print(data, LINE2(4));
}

void handle_engine_temp_data(uint8_t *data, uint8_t len) 
{
    //Implement the temperature function
    clcd_print(data, LINE2(13));
}

void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    uint8_t state = data[0];
    
    
        if(state == e_ind_off)
        {
            flag = 0;
            clcd_print("  ",LINE1(14));
        }
        else if(state == e_ind_left)
        {
            RIGHT_IND_OFF();   
            flag = 1;
            clcd_print("<-",LINE1(14));
        }  
        else if(state == e_ind_right)
        {
            LEFT_IND_OFF(); 
            flag = 2;
            clcd_print("->",LINE1(14));
        }
    

    //Implement the indicator function
    
}

void process_canbus_data() 
{   
    //process the CAN bus data
    uint16_t var_msg_id = 0;
    uint8_t var_len = 0, var_data[8];
    can_receive(&var_msg_id, var_data, &var_len);
    
    switch(var_msg_id)
    {
        case SPEED_MSG_ID:
        {
            handle_speed_data(var_data,var_len);
            break;
        }
        case GEAR_MSG_ID:
        {
            handle_gear_data(var_data,var_len);
            break;
        }
        case RPM_MSG_ID:
        {
            handle_rpm_data(var_data,var_len);
            break;
        }
        case ENG_TEMP_MSG_ID:
        {
            handle_engine_temp_data(var_data,var_len);
            break;
        }
        case INDICATOR_MSG_ID:
        {
            handle_indicator_data(var_data,var_len);
            break;
        }
    }
}