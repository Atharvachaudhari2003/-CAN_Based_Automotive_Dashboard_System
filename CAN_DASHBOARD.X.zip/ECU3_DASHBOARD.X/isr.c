/*
 * File:   isr.c
 * Author: DELL
 *
 * Created on 22 March, 2026, 2:33 PM
 */


#include <xc.h>

extern uint8_t blink_flag;
extern unsigned int count;

void __interrupt() isr(void)
{
   // static unsigned int count = 0;
    
    if(TMR0IF == 1)
    {
        TMR0IF = 0;
        TMR0 = TMR0 + 8;
        count++; 
    }
    return;
}
